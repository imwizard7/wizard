package com.stock.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.stock.beans.ErrInfo;

@ControllerAdvice
public class ExceptionController {
	
	public ErrInfo handlingException(Exception e,HttpServletRequest req) {
		String message=e.getMessage();
		String url=req.getRequestURL().toString();
		return new ErrInfo(message,url);
	}

}
