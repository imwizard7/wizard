package com.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stock.beans.Input;
import com.stock.beans.Stock;
import com.stock.exception.StockException;
import com.stock.service.IStockService;

@RestController
public class StockController {
	
	@Autowired
	IStockService service;
	
	//get All Stock
	@GetMapping("/stocks")
	public List<Stock> all(){
		return service.allStock();
	}
	
	//get Stock by ID
	@GetMapping("/stock/{id}")
	public Stock find(@PathVariable int id) throws StockException {
		Stock st=service.findStock(id);
		if(st==null)
			throw new StockException("Id not Found");
		return st;
	}
	
	//add Stock 
	@PostMapping("/stock")
	public Stock add(@RequestBody Input ip) {
		Stock st=service.addInput(ip);
		service.addStock(st);
		return st;
	}
	
	//delete Stock
	@DeleteMapping("/stock/{id}")
	public ResponseEntity<String> delete(@PathVariable int id){
		service.deleteStock(id);
		return new ResponseEntity<>("Stock Deleted Successfully",HttpStatus.OK);
	}
	
	//update Stock
	@PutMapping("/stock{id}")
	public Stock update(@RequestBody Input ip) {
		Stock st=service.addInput(ip);
		return service.addStock(st);
	}

}
