package com.stock.exception;

public class StockException extends Exception {

	String s;

	public StockException(String s) {
		super(s);
	}
	
}
