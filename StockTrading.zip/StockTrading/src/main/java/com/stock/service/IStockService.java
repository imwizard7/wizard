package com.stock.service;

import java.util.List;

import com.stock.beans.Input;
import com.stock.beans.Stock;

public interface IStockService {
	
	public List<Stock> allStock();
	
	public Stock addStock(Stock st);
	
	public Stock addInput(Input ip);
	
	public void deleteStock(int id);
	
	public Stock findStock(int id);

}
