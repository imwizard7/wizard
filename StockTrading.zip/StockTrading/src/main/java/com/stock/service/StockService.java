package com.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.beans.Input;
import com.stock.beans.Stock;
import com.stock.dao.StockDao;

@Service
public class StockService implements IStockService {
	
	@Autowired
	StockDao repo;
	@Autowired
	Stock stock;

	@Override
	public List<Stock> allStock() {
		return repo.findAll();
	}

	int id=0;
	@Override
	public Stock addInput(Input ip) {
		double amount=((ip.getPrice()*ip.getQuantity())-((ip.getPrice()*ip.getQuantity()*0.05)));
		stock.setAmount(amount);
		stock.setBrokerage(0.5);
		stock.setName(ip.getName());
		stock.setId(++id);
		stock.setQuantity(ip.getQuantity());
		stock.setPrice(ip.getPrice());
		return stock;
	}
	@Override
	public Stock addStock(Stock st) {
		return repo.save(st);
	}
	@Override
	public void deleteStock(int id) {
		repo.deleteById(id);
	}
	@Override
	public Stock findStock(int id) {
		return repo.findById(id).orElse(null);
	}

	

}
