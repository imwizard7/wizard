import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showbal',
  templateUrl: './showbal.component.html',
  styleUrls: ['./showbal.component.css']
})
export class ShowbalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
