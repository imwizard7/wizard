import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customer :Customer= new Customer();

  constructor(private service:CustomerService) { }

  ngOnInit() {
  }

  

  addCust(data){
    alert("congratulations"+" "+data.value.custName);
    this.customer.custName=data.value.custName;
    this.customer.custMobile=data.value.custMob;
    this.customer.custBalance=data.value.custBal;
    this.service.addCustomer(this.customer);
  }

}
