import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Customer } from './customer';
import { Observable } from '../../node_modules/rxjs';



@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private baseUrl = 'http://localhost:7044/bank/create';

  constructor(private http:HttpClient) { }

  addCustomer(customer){
    console.log(customer);
    return this.http.post<Customer>(this.baseUrl, customer);
  }
}
