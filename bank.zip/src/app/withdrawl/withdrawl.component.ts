import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawl',
  templateUrl: './withdrawl.component.html',
  styleUrls: ['./withdrawl.component.css']
})
export class WithdrawlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
