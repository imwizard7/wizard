export class Customer {
    custName:string;
    custMobile:number;
    custBalance:number;
    custAccountNo:number; 
}