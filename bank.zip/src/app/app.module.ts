import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {RouterModule,Routes} from '@angular/router'
import {FormsModule} from '@angular/forms'
import {HttpClientModule} from '@angular/common/http'

import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { CustomerComponent } from './customer/customer.component';
import { ShowbalComponent } from './showbal/showbal.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawlComponent } from './withdrawl/withdrawl.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';

const routes:Routes =[
  {path:'newcustomer',component:CustomerComponent},
  {path:'showBalance',component:ShowbalComponent},
  {path:'deposit',component:DepositComponent},
  {path:'withdrawl',component:WithdrawlComponent},
  {path:'fundtransfer',component:FundtransferComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    ShowbalComponent,
    DepositComponent,
    WithdrawlComponent,
    FundtransferComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
