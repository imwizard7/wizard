import { Injectable } from '@angular/core';
import { Employee } from "./Employee";
import { Observable } from 'rxjs';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

   
   static arr:Employee[] = [];

  constructor() { }

  addEmpService(data) {
    let obj = new Employee();
    obj.id=data.id;
    obj.name=data.name;
    obj.email=data.email;
    obj.phone=data.phone;
    EmployeeService.arr.push(obj);
    //return this.arr;
    alert(EmployeeService.arr[0].name+" "+"Added Successfully");
  }

  listEmpService():Employee[]{
    //alert(this.arr[0].id);
    return EmployeeService.arr;
    
  }

  update(i) {
    alert("update method not available");
  }

  delete(i) {
    EmployeeService.arr.splice(i,1);
  }
}
