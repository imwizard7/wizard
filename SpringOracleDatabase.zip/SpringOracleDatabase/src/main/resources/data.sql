insert into employee values(101,'shubham',10000);
insert into employee values(102,'surajit',11000);
insert into employee values(103,'harish',12000);