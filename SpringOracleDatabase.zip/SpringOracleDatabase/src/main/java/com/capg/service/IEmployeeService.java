package com.capg.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.capg.beans.Employee;

public interface IEmployeeService {
	
	public Employee getEmployeeById(@PathVariable("id")int eid);
	
	public List<Employee> getAllEmployee();
	
	public void deleteEmployeeById(int eid);
	
	public Employee addEmployee(Employee emp);
	
	public Employee updateEmployee(Employee emp);
	
	public List<Employee> getBySalary(double salary);
	
	public List<Employee> getByRange();
	
	public List<Employee> sortByName();
}
