package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.beans.Employee;
import com.capg.dao.EmployeeRepository;

@Service
public class EmployeeServiceImp implements IEmployeeService {
	
	@Autowired
	EmployeeRepository repo;

	@Override
	public Employee getEmployeeById(int eid) {
		return repo.findById(eid).orElse(new Employee());
	}

	@Override
	public List<Employee> getAllEmployee() {
		return repo.findAll();
	}

	@Override
	public void deleteEmployeeById(int eid) {
		repo.deleteById(eid);
	}

	@Override
	public Employee addEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public List<Employee> getBySalary(double salary) {
		// TODO Auto-generated method stub
		return repo.findBySalary(salary);
	}

	@Override
	public List<Employee> getByRange() {
		// TODO Auto-generated method stub
		return repo.findByRange();
	}

	@Override
	public List<Employee> sortByName() {
		// TODO Auto-generated method stub
		return repo.sortName();
	}

	
	
	
	

}
