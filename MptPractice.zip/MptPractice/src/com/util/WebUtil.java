package com.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebUtil {
	
	public static WebDriver getDriver() {
		
		String path="D:\\BddSeleniumWorkSpace\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		WebDriver driver= new ChromeDriver();
		return driver;
	}

}
