package com.pageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.util.WebUtil;

public class PageObjectRepository {

	WebDriver driver;
	
	public WebDriver getWebDrive() {
		this.driver=WebUtil.getDriver();
		return driver;
	}
	
	public WebElement getPrice() {
		WebElement price=driver.findElement(By.id("price"));
		return price;
	}
	
	public WebElement getQuantity() {
		WebElement quantity=driver.findElement(By.id("quantity"));
		return quantity;
	}
	
	public WebElement getTotal() {
		WebElement total=driver.findElement(By.id("total"));
		return total;
	}
	
	public WebElement getButton() {
		WebElement button=driver.findElement(By.id("multiply"));
		return button;
	}
}
