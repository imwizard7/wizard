package com.definition;

import org.openqa.selenium.WebDriver;

import com.pageFactory.PageObjectRepository;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {
	
	WebDriver driver;
	PageObjectRepository pom= new PageObjectRepository();
	
	@Given("^Navigate to Display URL$")
	public void navigate_to_Display_URL() throws Throwable {
	    this.driver=pom.getWebDrive();
	    driver.get("D:\\BddSeleniumWorkSpace\\MptPractice\\Html\\display.html");
	}

	@When("^User Enter Price \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_Enter_Price_and(String price, String quantity) throws Throwable {
		
		pom.getPrice().sendKeys(price);
		pom.getQuantity().sendKeys(quantity);
		pom.getButton().click();
	}

	@Then("^Total Data Displayed$")
	public void total_Data_Displayed() throws Throwable {
	    String value= (pom.getTotal().getAttribute("value"));
	    //System.out.println(value);
		int num=Integer.parseInt(value); 
		if(num==40) {
			System.out.println("Validated");
			driver.close(); }
		else 
			System.out.println("Not Validated");
		 
	}
	
	
	
	@When("^User Enter Invalid Price \"([^\"]*)\" and Quantity \"([^\"]*)\"$")
	public void user_Enter_Invalid_Price_and_Quantity(String price, String quantity) throws Throwable {
	    pom.getPrice().sendKeys(price);
	    pom.getQuantity().sendKeys(quantity);
	    pom.getButton().click();
	}

	
	@When("^User Enter valid Price \"([^\"]*)\" and Invalid Quantity \"([^\"]*)\"$")
	public void user_Enter_valid_Price_and_Invalid_Quantity(String price, String quantity) throws Throwable {
		pom.getPrice().sendKeys(price);
	    pom.getQuantity().sendKeys(quantity);
	    pom.getButton().click();
	}
	
	@Then("^Total Data Not Displayed$")
	public void total_Data_Not_Displayed() throws Throwable {
		driver.switchTo().alert().accept();
	    System.out.println("Form Invalidate");
	}


}
