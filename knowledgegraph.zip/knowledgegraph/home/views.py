from django.shortcuts import render, redirect
import json

# Create your views here.


def homepage(request):
    kgimg = 'static/images/default.png'
    temp = open('static/json/demo.json')
    data = json.load(temp)
    arr = []
    for i in data:
        if isinstance(i, dict):
            for key, value in i.items():
                arr.append(key)
                #print(key, value)
        else:
            print(i)
    return render(request, 'homepage.html', {'data':arr,'kgimg':kgimg})
    # return render(request, 'homepage.html')

def show(request):
    kgimg = 'static/images/kg1.png'
    temp = open('static/json/kngraph.json')
    data = json.load(temp)
    arr = []
    # arr.append(data)
    for i in data:
        if isinstance(i, dict):
            for key, value in i.items():
                arr.append(key)
                #print(key, value)
        else:
            print(i)
    return render(request, 'homepage.html', {'data':arr,'kgimg':kgimg})



allmessage = []
allreply = []
def chat(request):
    kgimg = 'static/images/kg1.png'
    message = request.POST['message']
    allmessage.append(message)
    if message == "headquater":
        allreply.append("My Pc")
    else:
        allreply.append("I do not understand..")
    val = "chatting..."
    return render(request, 'homepage.html', {'kgimg':kgimg, 'chat':zip(allmessage,allreply)})
    # return render(request, 'homepage.html', {'kgimg':kgimg, 'allmssg':allmessage, 'allreply':allreply})