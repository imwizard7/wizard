from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage, name="home-page"),
    path('url', views.show, name="show"),
    path('chat', views.chat, name="chat"),
]
