import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'knowledge-graph';

  imagesrc: any= "assets/default.png";
  knowlegdeGraph: any = [];
  inputText:string;
  message: string;
  allmssg:any[]=[];
  reply: any[]= [];
  keydata:any[];


  constructor(private httpClient: HttpClient, private router: Router){}
  ngOnInit(){
    this.httpClient.get("assets/demo.json").subscribe(data=>{
      this.populate(data);
      this.knowlegdeGraph=data;
    });
  }

  // Populating the Relations
  populate(data) {
    console.log("Populating");
    let obj= data;
    for(let i=0;i<obj.length;i++) {
      console.log(obj[i])
      this.keydata= Object.keys(obj[i])
    }
    console.log(this.keydata)
  }
  
  // Fetching Data from Input given by User
  fetchdata(data:any) {
    console.log(data.textdata)
    console.log(this.inputText);
    this.imagesrc="assets/kg1.png"
    //this.httpClient.get("assets/kngraph.json").subscribe(x=>this.knowlegdeGraph=x);
    this.httpClient.get("assets/kngraph.json").subscribe(data=>{
      this.populate(data);
      this.knowlegdeGraph=data;
    });
  }

  // Query Window
  chat() {
    //alert(this.message);
    let str;
    this.allmssg.push(this.message)
    switch(this.message) {
      case 'founded':
        str= '1 October 1955';
        this.reply.push(str);
        break;
      case 'headquaters':
        str= '833 Collins Street Docklands, Melbourne, Australia';
        this.reply.push(str);
        break;
      case 'website':
        str= '	www.anz.com';
        this.reply.push(str);
        break;
      default:
        str= 'Sorry, I am not trained to answer this question yet. I am still learning. Thank you.';
        this.reply.push(str);
        break;
    }
  }
}
