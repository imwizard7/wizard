package com.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import com.utility.*;


public class UserInterface {
    
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner sc =new Scanner(System.in);
        //Fill the UI code
        Shop shopObject=new Shop();
        System.out.println("Enter the no of Face Creams you want to store:");
        int totalProduct=sc.nextInt();
        
        for(int i=1;i<=totalProduct;i++)
        {
            System.out.println("Enter the key"+i);
            int key=sc.nextInt();
            System.out.println("Enter the value"+i);
            sc.nextLine();
            String name=sc.nextLine();
            //System.out.println(name);
            shopObject.addProductDetails(key,name);
        
        }
         Map<Integer,String> productMapObj=shopObject.getProductMap();
         for(Map.Entry<Integer,String> m: productMapObj.entrySet())
         {
             System.out.println(m.getKey()+" "+m.getValue());
         }
    
         System.out.println("Enter the product type to be searched");
         String type=sc.next();
         List <String>list=shopObject.searchBasedOnproduct(type);
    
         Iterator<String> iterator=list.iterator();
         while(iterator.hasNext())
         {
             System.out.println(iterator.next());
             
         } 
         sc.close();
    }
}




