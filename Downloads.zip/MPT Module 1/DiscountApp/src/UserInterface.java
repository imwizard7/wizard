
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;


public class UserInterface {
	
	
	
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int noOfProducts=sc.nextInt();
		String products[]=new String[noOfProducts];
		for(int i=0;i<noOfProducts;i++){
			products[i]=sc.next();
		}
		
		LinkedHashMap<String,Double> map=new LinkedHashMap<String,Double>();
		
		String array[]=new String[noOfProducts];
		double discount[]=new double[noOfProducts];
		for(int i=0;i<noOfProducts;i++) {
			array=products[i].split(",");
			discount[i]=Double.parseDouble(array[1])*Double.parseDouble(array[2])/100;
			double dis=Integer.parseInt(array[1])*Integer.parseInt(array[2])/100;
			map.put(array[0], dis);
		}
		
		double small = discount[0]; 
	    for(int i=0;i<noOfProducts;i++) {
	        if ( discount[i]<small )
	            small = discount[i];
	    }
	    
		
	    Iterator<Map.Entry<String,Double>> iterator=map.entrySet().iterator();
	    while(iterator.hasNext()) {
	    	Map.Entry<String,Double> entry=iterator.next();
	    	if(entry.getValue()==small)
	    		System.out.println(entry.getKey()+" "+entry.getValue());
	    }
		
	}

}
