import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assume.assumeFalse;
import org.junit.Test;

 

public class EmployeeTest 
{
    @Test
    public void testcalNetPay1() {
        Employee emp = new Employee(1, "Surajit", 3000, 5);
        double actual = emp.calNetPay();
        double expected = 3000;
        assertTrue(expected == actual);
    }

 

    @Test
    public void testcalNetPay2() {
        Employee emp = new Employee(2, "Akash", 5000, 3);
        double actual = emp.calNetPay();
        double expected = 5000;
        assertTrue(expected == actual);
    }
    
    @Test
    public void testcalNetPay3() {
        Employee emp = new Employee(3, "Shubham", 10000, 8);
        double Actual = emp.calNetPay();
        double Expected = 9200;
        assertTrue(Expected == Actual);
    }
}