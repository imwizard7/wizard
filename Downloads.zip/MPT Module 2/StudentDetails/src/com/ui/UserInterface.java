package com.ui;

import java.util.Scanner;

import com.bean.Student;
import com.utility.College;

public class UserInterface {

	public static void main(String args[]) {
		
		int detail1 = 0;
		System.out.println("Enter the number of student details");
		Scanner scanner = new Scanner(System.in);
		College college = new College();
		detail1 = Integer.parseInt(scanner.nextLine());
		System.out.println("Enter the student details");
		
		
		for (int i = 0; i < detail1; i++) {
			
			String details = scanner.nextLine();
			Student student = new Student();
			student.parseData(details);
			college.addStudent(student);
			
		}
		
		
		System.out.println("Enter the grade");
		
		String detail4 = scanner.nextLine();
		System.out.println("Count:" + college.countBasedOnGrade(detail4));
		
		scanner.close();
	}

}
