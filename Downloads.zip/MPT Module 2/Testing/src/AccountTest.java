import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class AccountTest {
	
	int accountId=123;
	String accountType="saving";
	int balance=5000;
	Account acc=new Account(accountId,accountType,balance);
	
	@Test
	public void test1() {
		Account expected=new Account(123,"saving",5000);
		assertEquals(expected.deposit(5000),true);
	}
	
	@Test
	public void test2() {
		Account expected=new Account(123,"saving",5000);
		assertEquals(expected.deposit(0),false);

	}
}
