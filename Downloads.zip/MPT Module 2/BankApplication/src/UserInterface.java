import java.util.Scanner;

public class UserInterface {

	public static void main(String a[]) {
		Scanner scanner = new Scanner(System.in);
		int totalEmployees = scanner.nextInt();
		String employees[] = new String[totalEmployees];
		for (int i = 0; i < totalEmployees; i++) {
			employees[i] = scanner.next();
		}
		
		int count = 0;
		StringBuffer stringbuffer = new StringBuffer();
		
		for (String s : employees) {
			String[] newstr = new String[2];
			newstr = s.split(",");
			//System.out.println(newstr[0]);
			newstr[1] = newstr[1].replaceAll(":", "");
			int number = Integer.parseInt(newstr[1]);
			if (number > 930) {
				count++;
				stringbuffer.append(newstr[0] + " ");
			}
		}
		
		
		System.out.println(count + " " + stringbuffer.toString() + "are late");
        scanner.close();
	}

}