package bus;

public class SeatNoNotValidException extends Exception{
	
	SeatNoNotValidException(String string) {
		super(string);
	}
}
