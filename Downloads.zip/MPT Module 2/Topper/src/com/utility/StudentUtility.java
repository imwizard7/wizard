package com.utility;

import java.util.List;
import java.util.Map;

public class StudentUtility {
	private Map<Integer,Integer> studentMap;

	
	public Map<Integer, Integer> getStudentMap() {
		return studentMap;
	}

	public void setStudentMap(Map<Integer, Integer> studentMap) {
		this.studentMap = studentMap;
	}

	//This method should add the rollNumber as key and marks value into the studentList map
	public void addStudentDetails(int rollNumber,int marks){
		
	}
	
	/*
	 * This method should return the list of student roll numbers who have scored the maximum mark
	 * For Example :If the map contains the key and value as:
	 *  1 80
		2 90
		3 60
		4 90
		5 75

	 * For the above input this method should return the 2,4 as output.
	 */
	
	public List<Integer> findToppers()
	{

			return null;
		
		
	
	}


}
