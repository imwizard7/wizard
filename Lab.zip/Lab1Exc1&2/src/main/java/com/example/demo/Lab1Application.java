package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Lab1Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context= SpringApplication.run(Lab1Application.class, args);
		
		Employee emp=context.getBean(Employee.class);
		SBU bu=context.getBean(SBU.class);
		
		//Employee emp= new Employee();
		
		emp.setId(12345);
		emp.setName("Harriet");
		emp.setSalary(40000);
		//emp.setBu("PES-BU");
		emp.setAge(30);
		
		bu.setCode("PES-BU");
		bu.setHead("Kiran Rao");
		bu.setName("Engineering Service");
		
		System.out.println("Employee Details :");
//		System.out.println("Employee ID :"+emp.getId());
//		System.out.println("Employee Name :"+emp.getName());
//		System.out.println("Employee Salary :"+emp.getSalary());
//		System.out.println("Employee BU :"+emp.getBu());
//		System.out.println("Employee Age :"+emp.getAge());
		
		System.out.println(emp);
	}

}
