package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class SBU {
	
	private String code;
	private String name;
	private String head;
	@Override
	public String toString() {
		return "SBU [sbuCode=" + code + ",sbuHead=" + head + " ,sbuName=" + name + "]";
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHead() {
		return head;
	}
	public void setHead(String head) {
		this.head = head;
	}
	

}
