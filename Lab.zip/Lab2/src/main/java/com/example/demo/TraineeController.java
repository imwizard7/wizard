package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.TraineeDao;
import com.example.demo.pojo.Trainee;

@Controller
public class TraineeController {
	
	@Autowired
	TraineeDao repo;
	
	@GetMapping("/")
	public String login() {
		return "login";
	}
	
	@GetMapping("/management")
	public String management() {
		return "management";
	}
	
	@GetMapping("/addDetails")
	public String add() {
		return "addTrainee";
	}
	
	@GetMapping("/addDetails/added")
	public ModelAndView addTrainee(Trainee emp) {
		ModelAndView mv= new ModelAndView("traineeData");
		System.out.println(emp);
		mv.addObject("empKey",emp);
		repo.save(emp);
		return mv;
	}

}
