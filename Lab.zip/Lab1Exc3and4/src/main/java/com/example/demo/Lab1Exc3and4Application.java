package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Lab1Exc3and4Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(Lab1Exc3and4Application.class, args);
		
		SBU sbu=context.getBean(SBU.class);
		Employee emp=context.getBean(Employee.class);
		Employee emp1=context.getBean(Employee.class);
		
		sbu.setSbuCode("PES-BU");
		sbu.setSbuHead("Kiran Rao");
		sbu.setSbuName("Product Engineering Service");
		
		emp.setAge(30);
		emp.setId(12345);
		emp.setName("Harriet");
		emp.setSalary(40000);
		//sbu.setEmp(emp);
		
		emp1.setAge(22);
		emp1.setId(12346);
		emp1.setName("King");
		emp1.setSalary(50000);
		//sbu.setEmp(emp1);
		
		System.out.println(sbu);
	}

}
