package bean;

public class Account {
	 int accountNum=0;
	 static int accCounter=1;
	 double balance=0;
	 Customer custDetails;
	 
	 
	public Account() {
		super();
	}
	
	public int account() {
		int acc=accCounter;
		accCounter++;
		return acc;
	}


	public Account(Customer custDetails) {
		super();
		this.accountNum = account();
		this.balance = balance;
		this.custDetails = custDetails;
	}


	public int getAccountNum() {
		return accountNum;
	}


	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public Customer getCustDetails() {
		return custDetails;
	}


	public void setCustDetails(Customer custDetails) {
		this.custDetails = custDetails;
	}


	@Override
	public String toString() {
		return "Account [accountNum=" + accountNum + ", balance=" + balance + ", custDetails=" + custDetails + "]";
	}

	
	
		 
	 
	 
	 
	 
	 
	 
	 
	 

}
