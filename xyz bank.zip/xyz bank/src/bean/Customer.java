package bean;

public class Customer {
	String custName;
	long custMobile;
//    int accountNum=0;
//    static int accCounter=1;
//    double balance=0;
	
	
	public Customer() {
		super();
	}
//	public int account() {
//		int acc=accCounter;
//		accCounter++;
//		return acc;
//	}


	public Customer(String custName, long custMobile) {
		super();
		this.custName = custName;
		this.custMobile = custMobile;
		//accountNum=account();
		
	}
	
	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public long getCustMobile() {
		return custMobile;
	}


	public void setCustMobile(long custMobile) {
		this.custMobile = custMobile;
	}


	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", custMobile=" + custMobile + "]";
	}
	
//	public int getAccountNum() {
//		return accountNum;
//	}
//	public void setAccountNum(int accountNum) {
//		this.accountNum = accountNum;
//	}
//	
//	public double getBalance() {
//		return balance;
//	}
//	public void setBalance(double balance) {
//		this.balance = balance;
//	}
//	@Override
//	public String toString() {
//		return "Customer [custName=" + custName + ", custMobile=" + custMobile + ", accountNum=" + accountNum
//				+ ", balance=" + balance + "]";
//	}
	
	
	
	
	
	
}