package service;
import java.util.HashMap;
import ui.*;
import bean.*;
import dao.*;
import exception.*;

public class AccountService {
	
	AccountDao custdao=new AccountDao();
	HashMap<Integer,Account> hm=custdao.retrieveCustomer();
	
	public void storeCustDetails(Account c) {
		custdao.storeCustomer(c);
	}
	
	public HashMap retrieveCustDetails() {
		HashMap hm=custdao.retrieveCustomer();
		return hm;
	}
	
	
	
	public void showBalance(int balshow) {
		HashMap hm=custdao.retrieveCustomer();
		try {
			if(hm.containsKey(balshow)) {
				//HashMap hm=accno.retrieveCustDetails();
				System.out.println(hm.get(balshow)); }
			else
				throw new AccountException("Account No Doesn't Exist");
		} catch (Exception e) {
			System.out.println("Please Try Again");
		}
	}
	
	public void depositMoney(int acc,double amt) {
		try {
			if(hm.containsKey(acc)) {
				Account c=hm.get(acc);
				double newbal3=amt+c.getBalance();
				c.setBalance(newbal3);
				System.out.println("Money succesfully deposited"); }
			else
				throw new AccountException("Account No Doesn't Exist");
		} catch (Exception e) {
			System.out.println("Please Try Again");
		}
	}
	
	public void withdrwalMoney(int accno,double withbal) {
		Account accwith=hm.get(accno);
		//System.out.println("Available Balance $:"+accwith.getBalance());
		double currbal=accwith.getBalance();
		double updatebal=0;
		try {
			if(currbal>withbal) {
				updatebal=currbal-withbal;
				System.out.println("withdrawl succesfully");
				accwith.setBalance(updatebal);}
					else
						throw new WithdrawlException("Available Balance Low");
			} catch (Exception e) {
				System.out.println("Try Again");
			}
	}
	
	public void fundtransfer(int withacc,int depoacc,double transfermoney) {
		Account wacc=hm.get(withacc);
		//System.out.println("Available Balance :$"+wacc.getBalance());
		Account dacc=hm.get(depoacc);
		try {
			if(wacc.getBalance()>transfermoney) {
				double newwacc=wacc.getBalance()-transfermoney;
				double newdacc=dacc.getBalance()+transfermoney;
				System.out.println("Transfer Successfully");
				wacc.setBalance(newwacc);
				dacc.setBalance(newdacc);
			}
			else
				throw new FundtransferException("Available Balance is Low");
		} catch (Exception e) {
			System.out.println("Try Again");
		}
	}


}
