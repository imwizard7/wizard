package service;

import java.util.HashMap;

import bean.Account;

public interface AccountServiceIntf {
	
	public void storeCustDetails(Account c);
	
	public HashMap retrieveCustDetails();
	
	public void showBalance(int balshow);
	
	public void depositMoney(int acc,double amt);
	
	public void withdrwalMoney(int accno,double withbal);
	
	public void fundtransfer(int withacc,int depoacc,double transfermoney);

}
