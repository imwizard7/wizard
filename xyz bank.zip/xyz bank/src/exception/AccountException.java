package exception;

public class AccountException extends Exception {
	
	public AccountException(String s) {
		System.out.println(s);
	}

}
