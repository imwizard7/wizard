package exception;

public class CustomerValidation extends Exception {
	
	public CustomerValidation(String s) {
		System.out.println(s);
	}

}
