package dao;

import java.util.HashMap;

import bean.Account;

public interface AccountDaoIntf {
	
	public void storeCustomer(Account c);
	
	public HashMap retrieveCustomer();

}
