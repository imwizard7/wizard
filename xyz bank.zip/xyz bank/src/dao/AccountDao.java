package dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import bean.*;
import service.AccountService;

public class AccountDao {

	static HashMap<Integer,Account> hashmap=new HashMap<Integer,Account>();
	
	

	public void storeCustomer(Account c) {
		int k=c.getAccountNum();
		hashmap.put(k,c);
	}
	
	public HashMap retrieveCustomer() {
		return hashmap;

	}

}
