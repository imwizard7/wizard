package ui;
import bean.*;
import service.AccountService;
import java.util.ArrayList;
import java.util.HashMap;
import ui.AccountData;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int choice=0;
		System.out.println("\tWELCOME TO MY BANK");
		while(choice!=8) {
			System.out.println("ENTER YOUR CHOICE");
			System.out.println("\t1.create account");
			System.out.println("\t2.show balance");
			System.out.println("\t3.deposit");
			System.out.println("\t4.withdrawl");
			System.out.println("\t5.fund transfer");
			System.out.println("\t6.print transaction");
			System.out.println("\t7.exit");
			choice=sc.nextInt();
			switch(choice)
			{
				case 1:
					AccountData newacc=new AccountData();
					newacc.addCustomer();
					break;
				case 2:
					AccountData showbal=new AccountData();
					showbal.showBalance();
					break;
				case 3:
					AccountData deposit=new AccountData();
					deposit.deposit();
					break;
				case 4:
					AccountData withdrawl=new AccountData();
					withdrawl.withdrawl();
					break;
				case 5:
					AccountData fundtransfer=new AccountData();
					fundtransfer.fundtransfer();
					break;
				case 6:
					AccountData printTranscation=new AccountData();
					printTranscation.printtransaction();
					break;
				case 7:
					System.out.println("Bye\nHave a Nice Day");
					System.exit(0);
				default :
					System.out.println("Invalid choice");
			}
		}
	}
}
