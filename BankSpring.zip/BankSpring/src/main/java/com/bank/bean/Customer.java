package com.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="springcustomer")
public class Customer {
	
	@Id
	@SequenceGenerator(name="seq",sequenceName="Acc_sequence")
    @GeneratedValue(generator="seq")
	private int id;
	private String name;
	private long MobileNo;
	private long balance;
	private long accountNo;
	
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", MobileNo=" + MobileNo + ", balance=" + balance
				+ ", accountNo=" + accountNo + "]";
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(long mobileNo) {
		MobileNo = mobileNo;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	
}
