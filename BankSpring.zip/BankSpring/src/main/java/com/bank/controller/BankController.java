package com.bank.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.bean.Customer;
import com.bank.service.CustomerService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/bank")
public class BankController {
	
	@Autowired
	CustomerService service;
	
	@PostMapping(value = "/create")
	public Customer addCustomer(@RequestBody Customer customer) {
		System.out.println("hlo");
		System.out.println(customer);
		Customer cust = service.addCustomer(customer);
		return cust;
	}

}
