package com.bank.service;

import com.bank.bean.Customer;

public interface CustomerService {

	public Customer addCustomer(Customer cust);
}
