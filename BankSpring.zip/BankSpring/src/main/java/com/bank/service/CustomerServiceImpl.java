package com.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.bean.Customer;
import com.bank.dao.CustomerDao;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerDao repo;

	@Override
	public Customer addCustomer(Customer cust) {
		return repo.save(cust);
	}

}
