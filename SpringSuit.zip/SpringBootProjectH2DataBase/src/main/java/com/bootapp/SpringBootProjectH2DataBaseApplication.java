package com.bootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjectH2DataBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjectH2DataBaseApplication.class, args);
	}

}
