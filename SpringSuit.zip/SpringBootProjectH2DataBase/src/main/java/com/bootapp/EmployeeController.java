package com.bootapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EmployeeController {
	
	@Autowired
	DaoRepository repo;
	
	@RequestMapping("/")
	public String form() {
		return "form";
	}
	
	@GetMapping("/display")
	public String display(Employee emp,Model md) {
		md.addAttribute("empKey",emp);
		repo.save(emp);
		return "display";
	}

}
