package com.bootapp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	
	@Autowired
	Employee emp;
	
	@RequestMapping(value="/")
	public String form() {
		return "form";
	}
	
//	@RequestMapping(value="/disphttp")
//	public String display(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
//		
//		int eid=Integer.parseInt(request.getParameter("eid"));
//		String ename=request.getParameter("ename");
//		double salary=Double.parseDouble(request.getParameter("salary"));
//		
//		emp.setEid(eid);
//		emp.setEname(ename);
//		emp.setSalary(salary);
//		
//		session.setAttribute("empKey",emp);
//		
//		return "display";
//	}
	
//	@RequestMapping("/dis")
//	public String display(@RequestParam("eid")int eid,@RequestParam("ename")String ename,@RequestParam("sal")double sal,Model m) {
//		emp.setEid(eid);
//		emp.setEname(ename);
//		emp.setSalary(sal);
//		m.addAttribute("empKey",emp);
//		return "display";
//	}
	
	@PostMapping
	//@RequestMapping("/dis")
	public ModelAndView display(Employee emp) {
		
		ModelAndView mav= new ModelAndView();
		mav.addObject("emp",emp);
		mav.setViewName("display");
		return mav;
	}

}
