package packg.steps;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import packg.WebUtil;

public class StepDefinition {
	
	WebDriver driver=WebUtil.getWebDriver();
	
	@Given("^NAvigate to Icompass Url$")
	public void navigate_to_Icompass_Url() throws Throwable {
		
		driver.get("https://icompassweb.fs.capgemini.com/iCompass/#/");
	    
	}

	@When("^User Enter Login Credentials$")
	public void user_Enter_Login_Credentials(DataTable data) throws Throwable {
		List<List<String>> table=data.raw();
		
		WebElement user=driver.findElement(By.id("userName"));
		WebElement pass=driver.findElement(By.id("password"));
		
		
		String uname=table.get(0).get(0);
		String passw=table.get(0).get(1);
		
		user.sendKeys(uname);
		pass.sendKeys(passw);
	}


	@Then("^Validation should be Performed$")
	public void validation_should_be_Performed() throws Throwable {
	   WebElement login=driver.findElement(By.id("loginButton"));
	   login.click();
	}
}
