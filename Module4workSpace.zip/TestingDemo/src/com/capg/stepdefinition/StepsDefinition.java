package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {
	
	WebDriver driver=WebUtil.getWebDriver();
	
	@Given("^navigate to Icompass url$")
	public void navigate_to_Icompass_url() throws Throwable {
	    
		
		String url="https://icompassweb.fs.capgemini.com/iCompass/#/";
		driver.get(url);
		//driver.get("https://icompassweb.fs.capgemini.com/iCompass/#/");
		
	}

	@When("^User enter valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enter_valid_username_and_valid_password(String username, String password) throws Throwable {
		
		WebElement user=driver.findElement(By.id("userName"));
		user.sendKeys(username);
		WebElement pass=driver.findElement(By.id("password"));
		pass.sendKeys(password);
	   
	}

	@Then("^Login Successfully$")
	public void login_Successfully() throws Throwable {
	    
		WebElement login=driver.findElement(By.id("loginButton"));
		login.click();
		
		driver.close();
	}

	@Given("^navigate to Google url$")
	public void navigate_to_Google_url() throws Throwable {
		
		driver.navigate().to("https://www.google.com/"); // driver.get()
	    
	}

	@When("^User enter input \"([^\"]*)\"$")
	public void user_enter_input(String text) throws Throwable {
	    
		WebElement search=driver.findElement(By.name("q"));
		search.sendKeys(text);
		search.sendKeys("\n");
	}

	@Then("^Climate details displayed$")
	public void climate_details_displayed() throws Throwable {
	    System.out.println("Climate Displayed");
	    driver.close();
	}

	@When("^User click on image link$")
	public void user_click_on_image_link() throws Throwable {
	    
		//driver.navigate().to("https://www.google.com/"); // driver.get()
		WebElement imgLink=driver.findElement(By.className("gb_e"));
		imgLink.click();
	}

	@Then("^Display images page$")
	public void display_images_page() throws Throwable {
	   System.out.println("Google Image Search Page");
	   driver.close();
	}

	

}
