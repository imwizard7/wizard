$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/login.feature");
formatter.feature({
  "line": 3,
  "name": "Multiple Scenario Testing",
  "description": "",
  "id": "multiple-scenario-testing",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@SmokeTest"
    },
    {
      "line": 2,
      "name": "@Test"
    }
  ]
});
formatter.scenario({
  "line": 6,
  "name": "Login Icompass with Valid Credentials",
  "description": "",
  "id": "multiple-scenario-testing;login-icompass-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "navigate to Icompass url",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User enter valid username \"190047\" and valid password \"Love*Care\"",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Login Successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "StepsDefinition.navigate_to_Icompass_url()"
});
formatter.result({
  "duration": 8784604500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "190047",
      "offset": 27
    },
    {
      "val": "Love*Care",
      "offset": 55
    }
  ],
  "location": "StepsDefinition.user_enter_valid_username_and_valid_password(String,String)"
});
formatter.result({
  "duration": 234696000,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.login_Successfully()"
});
formatter.result({
  "duration": 224808400,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Display Climate Details",
  "description": "",
  "id": "multiple-scenario-testing;display-climate-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "navigate to Google url",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "User enter input \"chennai climate\"",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "Climate details displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "StepsDefinition.navigate_to_Google_url()"
});
formatter.result({
  "duration": 4145388000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "chennai climate",
      "offset": 18
    }
  ],
  "location": "StepsDefinition.user_enter_input(String)"
});
formatter.result({
  "duration": 2150197099,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.climate_details_displayed()"
});
formatter.result({
  "duration": 89700,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Display Google Images",
  "description": "",
  "id": "multiple-scenario-testing;display-google-images",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "navigate to Google url",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "User click on image link",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "Display images page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepsDefinition.navigate_to_Google_url()"
});
formatter.result({
  "duration": 3795918800,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.user_click_on_image_link()"
});
formatter.result({
  "duration": 1642569099,
  "status": "passed"
});
formatter.match({
  "location": "StepsDefinition.display_images_page()"
});
formatter.result({
  "duration": 64200,
  "status": "passed"
});
});