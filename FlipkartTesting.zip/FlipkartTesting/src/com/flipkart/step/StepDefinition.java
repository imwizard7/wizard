package com.flipkart.step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	WebDriver driver;
	
	@Given("^open the browser and enter URL$")
	public void open_the_browser_and_enter_URL() throws Throwable {
	    
		String path="C:\\\\Module4workSpace\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		driver= new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
		
	}

	@When("^enter username and password$")
	public void enter_username_and_password() throws Throwable {
		
	
		
	    
		WebElement user= driver.findElement(By.className("_2zrpKA"));
		user.sendKeys("7044358147");
		WebElement pass= driver.findElement(By.className("_3v41xv"));
		pass.sendKeys("7flipkart7");
		
		
	}

	@Then("^login Successfully$")
	public void login_Successfully() throws Throwable {
		
		
		
		WebElement login= driver.findElement(By.className("_7UHT_c"));
		login.click();
	}



}
