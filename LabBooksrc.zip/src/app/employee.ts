export class Employee {
    id:number;
    name:string;
    salary:string;
    department:string;
}