import { Injectable, ɵEMPTY_ARRAY } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }

  static emparr:Employee[]=[];

  addemployee(data) {
    alert(data.id+" "+data.name+" "+data.salary+" "+data.department);
    EmployeeService.emparr.push(data);
    return EmployeeService.emparr;
    
  }

  update(updata) {
    for(let i=0;i<EmployeeService.emparr.length;i++) {
      if(updata.id==EmployeeService.emparr[i].id) {
        EmployeeService.emparr[i].name=updata.name;
        EmployeeService.emparr[i].salary=updata.salary;
        EmployeeService.emparr[i].department=updata.department;
      }
    }
  }

  delete(i) {
    EmployeeService.emparr.splice(i,1);
  }
}
